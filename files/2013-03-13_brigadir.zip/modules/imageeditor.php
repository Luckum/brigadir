<?php
/**
 * Обработка картинок
 *
 * @category NW_CMS07_System
 * @package  ImageEditor
 * @author   Developer <development@nwpro.ru>
 * @license  http://opensource.org/licenses/bsd-license.php New BSD License
 * @link     http://www.nwpro.ru
 * @since    2011-06-10
 */
class ImageEditor
{
    protected $sourceImageResource;
    protected $destImageResource;
    protected $workImageResource;
    protected $sourceImagePath = '';
    protected $sourceWidth = 0;
    protected $sourceHeight = 0;
    protected $workWidth = 0;
    protected $workHeight = 0;

    public $destPath = null;
    public $destWidth = null;
    public $destHeight = null;
    public $forceSize = true;
    public $cropBool = false;
    public $increase = false;
    public $fillColor = "FFFFFF";
    public $quality = 80;

    public $valign = 'center'; // top, center, bottom
    public $align = 'center'; // left, center, right
    public $strFormat = '';
    public $destFormat = null;
    public $imageLogoProtect = false;
    public $imageLogoFile = '';
    public $logoPosX = 50;
    public $logoPosY = 50;
    public $logoSize = 0.7;

    protected static $mimeType = array(
        'x-ms-bmp' => 'bmp'
    );

    public function __construct($image)
    {
        if (!$fo = fopen($image, 'r')) {
            header('HTTP/1.0 404 Not Found');
            die("Can't open source image");
        } else
            fclose($fo);

        try {
            $arrSize = getimagesize($image);
        } catch (Exception $e) {

        }
        //Tools::debug($arrSize);

        if ($arrSize === false) {
            header('HTTP/1.0 404 Not Found');
            die("Can't get source image size");
        } else {
            $this->sourceWidth = $arrSize[0];
            $this->sourceHeight = $arrSize[1];
        }

        $strFormat = strtolower(substr($arrSize['mime'], strpos($arrSize['mime'], '/') + 1));
        $strFormat = Tools::ifsetor(self::$mimeType[$strFormat], $strFormat);
        $this->strFormat = $strFormat;
        $strFunc = "imagecreatefrom".$strFormat;

        //Tools::debug($strFunc);

        if (!function_exists($strFunc)) {
            header('HTTP/1.0 404 Not Found');
            new Exception_Main($msg = "Unsupported image format '".$strFormat."'");
            die($msg);
        }

        $this->sourceImageResource = call_user_func($strFunc, $image);

    }

    function process()
    {
        $arrPath = explode('.', $this->destPath);
        $this->destFormat = array_pop($arrPath);

        if (!is_numeric($this->destWidth) && !is_numeric($this->destHeight)) {
            $this->destWidth = $this->sourceWidth;
            $this->destHeight = $this->sourceHeight;
            $proportion = 1;
        } elseif (!is_numeric($this->destWidth) || !is_numeric($this->destHeight)) {
            if (!is_numeric($this->destWidth)) {
                $proportion = $this->destHeight / $this->sourceHeight;
                $this->destWidth = $this->sourceWidth * $proportion;
            } else {
                $proportion = $this->destWidth / $this->sourceWidth;
                $this->destHeight = $this->sourceHeight * $proportion;
            }
        } else {
            $proportionWidth = $this->destWidth / $this->sourceWidth;
            $proportionHeight = $this->destHeight / $this->sourceHeight;

            if ($this->cropBool)
                $proportion = ($proportionWidth>$proportionHeight?$proportionWidth:$proportionHeight);
            else
                $proportion = ($proportionWidth>$proportionHeight?$proportionHeight:$proportionWidth);
        }

        //Tools::debug($this->destWidth);

        if ($proportion > 1) {
            if (!$this->increase)
                $proportion = 1;
        }

        if ($this->sourceWidth < $this->destWidth && $this->sourceHeight < $this->destHeight) {
            if (!$this->forceSize) {
                $this->destWidth = $this->sourceWidth;
                $this->destHeight = $this->sourceHeight;
            }
        }

        $this->workWidth = $this->sourceWidth*$proportion;
        $this->workHeight = $this->sourceHeight*$proportion;

        if (!$this->forceSize && !$this->cropBool) {
            $this->destWidth = $this->workWidth;
            $this->destHeight = $this->workHeight;
        }

        $this->destImageResource = imagecreatetruecolor($this->destWidth, $this->destHeight);
        //Tools::debug(var_export(hexdec("0x".$this->fillColor), true));
        $fillColor = hexdec($this->fillColor);

        if ($this->destFormat != 'png') {
            imagefill($this->destImageResource, 0, 0, $fillColor);
        } else {
            imagealphablending($this->destImageResource, false);
            imagesavealpha($this->destImageResource, true);
            $trColor = imagecolorallocatealpha($this->destImageResource, 0, 0, 0, 127);
            imagefill($this->destImageResource, 0, 0, $trColor);
        }

        $dst_x = ($this->destWidth - $this->workWidth)/2;
        $dst_y = ($this->destHeight - $this->workHeight)/2;
        $src_x = 0;
        $src_y = 0;
        $dst_w = $this->workWidth;
        $dst_h = $this->workHeight;
        $src_w = $this->sourceWidth;
        $src_h = $this->sourceHeight;

        if ($this->valign == 'top')
            $dst_y = 0;
        if ($this->valign == 'bottom')
            $dst_y = $dst_y * 2;

        if ($this->align == 'left')
            $dst_x = 0;
        if ($this->align == 'right')
            $dst_x = $dst_x * 2;

        imagecopyresampled(
            $this->destImageResource,
            $this->sourceImageResource,
            $dst_x,
            $dst_y,
            $src_x,
            $src_y,
            $dst_w,
            $dst_h,
            $src_w,
            $src_h
        );

        if ($this->imageLogoProtect) {
            $logo = $this->getLogoStamp(
                imagecreatefrompng($this->imageLogoFile),
                array($dst_w, $dst_h),
                $this->logoSize
            );
            $posX = round(((imagesx($this->destImageResource)/2) - (imagesx($logo)/2))*$this->logoPosX/50);
            $posY = round(((imagesy($this->destImageResource)/2) - (imagesy($logo)/2))*$this->logoPosY/50);
            imagecopy($this->destImageResource, $logo, $posX, $posY, 0, 0, imagesx($logo), imagesy($logo));
        }

        //Tools::debug('!'); die();

        if ($this->destFormat != 'png') {
            imagejpeg($this->destImageResource, $this->destPath, $this->quality);
        } else {
            imagepng($this->destImageResource, $this->destPath);
        }

    }

    public function getLogoStamp($src, $img_sizes, $logoSize)
    {
        $width = ceil($img_sizes[0]*$logoSize);
        $height = ceil(imagesy($src)*$width/imagesx($src));
        if ($height > $img_sizes[1]) {
            $height = ceil($img_sizes[1]*$logoSize);
            $width = ceil(imagesx($src)*$height/imagesy($src));
        }
        $img = imagecreatetruecolor($width, $height);
        $ct = imagecolortransparent($img);
        imagefill($img, 0, 0, $ct);
        imagecopyresampled($img, $src, 0, 0, 0, 0, imagesx($img), imagesy($img), imagesx($src), imagesy($src));
        return $img;

    }

}

function imagecreatefrombmp($p_sFile)
{
    //    Load the image into a string
    $file    =    fopen($p_sFile, "rb");
    $read    =    fread($file, 10);
    while(!feof($file) && ($read<>""))
        $read    .=    fread($file, 1024);

    $temp    =    unpack("H*", $read);
    $hex    =    $temp[1];
    $header    =    substr($hex, 0, 108);

    //    Process the header
    //    Structure: http://www.fastgraph.com/help/bmp_header_format.html
    if (substr($header, 0, 4) == "424d") {
        //    Cut it in parts of 2 bytes
        $header_parts    =    str_split($header, 2);

        //    Get the width        4 bytes
        $width            =    hexdec($header_parts[19].$header_parts[18]);

        //    Get the height        4 bytes
        $height            =    hexdec($header_parts[23].$header_parts[22]);

        //    Unset the header params
        unset($header_parts);
    }

    //    Define starting X and Y
    $x                =    0;
    $y                =    1;

    //    Create newimage
    $image            =    imagecreatetruecolor($width, $height);

    //    Grab the body from the image
    $body            =    substr($hex, 108);

    //    Calculate if padding at the end-line is needed
    //    Divided by two to keep overview.
    //    1 byte = 2 HEX-chars
    $body_size        =    (strlen($body)/2);
    $header_size    =    ($width*$height);

    //    Use end-line padding? Only when needed
    $usePadding        =    ($body_size>($header_size*3)+4);

    //    Using a for-loop with index-calculation instaid of str_split to avoid large memory consumption
    //    Calculate the next DWORD-position in the body
    for ($i=0;$i<$body_size;$i+=3) {
        //    Calculate line-ending and padding
        if ($x>=$width) {
            //    If padding needed, ignore image-padding
            //    Shift i to the ending of the current 32-bit-block
            if ($usePadding)
                $i    +=    $width%4;

            //    Reset horizontal position
            $x    =    0;

            //    Raise the height-position (bottom-up)
            $y++;

            //    Reached the image-height? Break the for-loop
            if ($y>$height)
                break;
        }

        //    Calculation of the RGB-pixel (defined as BGR in image-data)
        //    Define $i_pos as absolute position in the body
        $i_pos    =    $i*2;
        $r        =    hexdec($body[$i_pos+4].$body[$i_pos+5]);
        $g        =    hexdec($body[$i_pos+2].$body[$i_pos+3]);
        $b        =    hexdec($body[$i_pos].$body[$i_pos+1]);

        //    Calculate and draw the pixel
        $color    =    imagecolorallocate($image, $r, $g, $b);
        imagesetpixel($image, $x, $height-$y, $color);

        //    Raise the horizontal position
        $x++;
    }

    //    Unset the body / free the memory
    unset($body);

    //    Return image-object
    return $image;

}
