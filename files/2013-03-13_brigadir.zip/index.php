<?php
/**
* The directory in which your application specific resources are located.
* The application directory must contain the bootstrap.php file.
*
* @see  .
*/
$application = 'nw';

/**
 * The directory in which your modules are located.
 *
 * @see  .
 */
$modules = 'modules';

/**
 * The directory in which the Kohana resources are located. The system
 * directory must contain the classes/core.php file.
 *
 * @see  .
 */
$system = 'system';

/**
 * The default extension of resource files. If you change this, all resources
 * must be renamed to use the new extension.
 *
 * @see  .
 */
define('EXT', '.php');

/**
* Set the PHP error reporting level. If you set this in php.ini, you remove this.
* @see  http://php.net/error_reporting
*
* When developing your application, it is highly recommended to enable notices
* and strict warnings. Enable them by using: E_ALL | E_STRICT
*
* In a production environment, it is safe to ignore notices and strict warnings.
* Disable them by using: E_ALL ^ E_NOTICE
*
* When using a legacy application with PHP >= 5.3, it is recommended to disable
* deprecated notices. Disable with: E_ALL & ~E_DEPRECATED
*/
error_reporting(E_ALL | E_STRICT);

/**
* End of standard configuration! Changing any of the code below should only be
* attempted by those with a working knowledge of Kohana internals.
*
* @see  .
*/

// Set the shortname for constant DIRECTORY_SEPARATOR
define('DS', DIRECTORY_SEPARATOR);

// Set the full path to the docroot
define("DOC_ROOT", realpath(dirname(__FILE__)).DS);

// Make the application relative to the docroot, for symlink'd index.php
if (is_dir(DOC_ROOT.$application))
    $application = DOC_ROOT.$application;

// Make the modules relative to the docroot, for symlink'd index.php
if (is_dir(DOC_ROOT.$modules))
    $modules = DOC_ROOT.$modules;

// Make the system relative to the docroot, for symlink'd index.php
if (is_dir(DOC_ROOT.$system))
    $system = DOC_ROOT.$system;

// Define the absolute paths for configured directories
define('PATH_APP', realpath($application).DS);
define('PATH_MOD', realpath($modules).DS);
define('PATH_SYS', realpath($system).DS);
define('PATH_FATAL_ERROR', PATH_APP.'default'.DS.'errors'.DS);

unset($application, $modules, $system);

/**
* Define the start time of the application, used for profiling.
*/
if (!defined('NWPF_START_TIME')) {
    define('NWPF_START_TIME', microtime(true));
}

/**
 * Define the memory usage at the start of the application, used for profiling.
 */
if (!defined('NWPF_START_MEMORY')) {
    define('NWPF_START_MEMORY', memory_get_usage());
}

// Bootstrap the application
require PATH_APP.'bootstrap_multi'.EXT;

/**
* Execute the main request. A source of the URI can be passed, eg: $_SERVER['PATH_INFO'].
* If no source is specified, the URI will be automatically detected.
*/
$response = Request::factory()->execute();
echo $response->body();

//Tools::debug($_SERVER, parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));

echo '<!-- Время генерации страницы: ', (microtime(true) - NWPF_START_TIME), ' сек. Использовано памяти ',
    (memory_get_usage() - NWPF_START_MEMORY), ' байт. Максимум ', memory_get_peak_usage(), ' -->';